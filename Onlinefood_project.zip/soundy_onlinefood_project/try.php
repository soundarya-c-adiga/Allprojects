<?php
include "connection.php";
$link=connect();

?>
